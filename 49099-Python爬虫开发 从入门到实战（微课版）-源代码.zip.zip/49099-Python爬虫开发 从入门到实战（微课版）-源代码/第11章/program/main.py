from scrapy import cmdline
cmdline.execute("scrapy crawl BlogSpider".split())
