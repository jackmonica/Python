# for循环从列表中取出每一个元素
# name_list = ['张三', '李四', '王五', '朱六']
# for name in name_list:
#     print(name)


# for 循环从字符串里面取出每一个字符
# title = '大家好，我叫kingname.'
# for character in title:
#     print(character)

# for 循环读取字典
# menu_dict = {'红烧肉': '100元', '水煮肉片': '50元', '鸡汤': '1角'}
# for key in menu_dict:
#     print('菜品：{}'.format(key))
#     print('价格：{}'.format(menu_dict[key]))
#     print('=============')

# for循环仅仅作为循环使用
# for i in range(5):
#     print('现在是第{}次循环'.format(i))

# continue
# name_list = ['张三', '李四', '王五', '朱六']
# for name in name_list:
#     if name == '王五':
#         continue
#     print(name)

#break
# name_list = ['张三', '李四', '王五', '朱六']
# for name in name_list:
#     if name == '王五':
#         break
#     print(name)

