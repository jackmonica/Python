from scrapy import cmdline
cmdline.execute("scrapy crawl checkSpider".split())
